from db_connection import DB
class SignUpDb:
    def __init__(self,ui):
        self.db =DB()
        self.ui = ui

    def check_user_email(self,email):

        stmt ="SELECT Name FROM UserInformation WHERE EmailAddress= '{}';".format(email)
        self.db.execute(stmt)
        result = self.db.fetch_all()
        self.db.db_commit()

        if len(result) == 1:
            return True
        return False

        # check if user email exists.

    def Add_user_information(self):
        name = self.ui.NameField.text()
        surname = self.ui.SurNameField.text()
        email_address = self.ui.EmailField_2.text()
        password = self.ui.PasswordField_.text()
        dob = self.ui.DOBDate.text() + self.ui.DOBDateMonth.text() + self.ui.DOBYear.text()
        gender = "male" if self.ui.MaleCheckBox.isChecked() else "female"

        sql_stmt = "INSERT INTO UserInformation(Name,SurName,EmailAddress,Password,Dob,Gender) VALUES ('{}','{}','{}','{}','{}','{}')".format(name,surname,email_address,password,dob,gender)
        self.db.execute(sql_stmt)
        self.db.db_commit()

    def add_user_address(self):
        flat_no = self.ui.FlatNumberField.text()
        street_name= self.ui.StreetNameField.text()
        city = self.ui.CityField.text()
        post_code = self.ui.PostCodeField.text()
        email_address = self.ui.EmailField_2.text()

        sql_stmt = "INSERT INTO UserAddress(FlatNo,StreetName,City,PostCode,EmailAddress) VALUES('{}','{}','{}','{}','{}');".format(flat_no, street_name,city,post_code,email_address)
        self.db.execute(sql_stmt)
        self.db.db_commit()

    def update_password(self,email,newpassword):
        stmt = "UPDATE UserInformation SET Password = '{}' WHERE EmailAddress = '{}';".format(newpassword,email)
        self.db.execute(stmt)
        self.db.db_commit()
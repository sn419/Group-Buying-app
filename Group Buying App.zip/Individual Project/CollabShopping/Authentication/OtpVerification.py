import smtplib
import random
from PyQt5 import  QtWidgets


class PasswordReset:
    def __init__(self,ui):
        self.ui = ui


    def clear_password_recovery_fields(self):
        self.ui.ResetEmailInputField.clear()
        self.ui.ResetConfirmPasswordInputField.clear()
        self.ui.resetPasswordInputField.clear()
        self.ui.OTPInputField_2.clear()

    def password_reset_hide(self):
        self.ui.ResetConfirmPasswordInputField.setEchoMode(QtWidgets.QLineEdit.Password)


class Otp:
    def __init__(self):
        self.otp = 0
        pass

    def generate(self):
        otp = ""
        for i in range(7):
            otp += str(random.randint(0,9))
        self.otp = otp


    def get_Otp(self):
        return self.otp


    def sendOtp(self,email):

        # email server credentials
        email_address = 'sanaullah.noory@gmail.com'
        email_password = 'abfyzwrlfibmtfgy'

        # recipient email address
        to_address = email

        # generate random 6-digit OTP
        self.generate()
        otp = self.otp

        # email message
        subject = 'Your OTP for authentication'
        body = f'Your OTP is {otp}. Please enter this code to proceed with your authentication.'
        message = f'Subject: {subject}\n\n{body}'

        # connect to email server and send message
        with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            smtp.login(email_address, email_password)
            smtp.sendmail(email_address, to_address, message)


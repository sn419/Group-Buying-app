import sys
from PyQt5 import QtWidgets, Qt5, QtCore
from PyQt5.QtWidgets import QApplication, QLabel, QDialog, QWidget, QStackedWidget, QMainWindow

from Authentication.AuthenticationUi.LoginPage import *
from Authentication.SignUpFunctions import *
from Authentication.AuthenticationSQL.SignUpDB import SignUpDb
from Authentication.OtpVerification import  *

class Login_Page(QDialog, Ui_Dialog):
    def __init__(self):
        super().__init__()
        flags = QtCore.Qt.WindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setWindowFlags(flags)
        self.setupUi(self)
        self.setFixedWidth(750)
        self.setFixedHeight(600)


        # Set loginPage to be the first page
        self.AuthenticationMenu.setCurrentWidget(self.LoginPage)

        # Navigate to sign up page
        self.SignUpButton.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.SignUpPage))

        # set  previous navigation for signUp pages
        self.SignUpPageOnePrevious_Btn.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.LoginPage))
        self.SignUpPageTwoPrevious_Btn.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.SignUpPage))
        self.RegisterPrev_Btn.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.SignUpPage2))

        # navigate to forgot password pages
        self.ForgotPasswordButton.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.PasswordResetEmail))

        # set previous navigation for forgotten password pages
        self.ForgottenPasswordEmailPrev_Btn.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.LoginPage))
        self.PasswordResetprev_Btn.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.PasswordResetEmail))
        self.NewPasswordPrev_btn.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.PasswordResetOTP))


    # Apply QLineEdit Restriction  for login and signup and forgotten password
        ui_restriction = SignUpUiFunctions(self)
        ui_restriction.apply_all_restriction()
        password_recovery_ui = PasswordReset(self)
        password_recovery_ui.password_reset_hide()



        # Set up signup database function and database
        SignUp_db = SignUpDb(self)
        register_otp_class = Otp()
        sign_up_logic_class =SignUpLogicalFunctions(self)


        """ ----------------------  Sign up -----------------"""
        # Apply Logical restriction to SignUpFirstPage
        def signup_page_one():

            if sign_up_logic_class. check_Signup_page_one_fields():

              signUp_email_input = self.EmailField_2.text()
              email_exist_db = SignUp_db.check_user_email(signUp_email_input)
              if not email_exist_db:
                self.AuthenticationMenu.setCurrentWidget(self.SignUpPage2)
              else:
                  print("the email exist, please enter a different email")

        self.NextButton.clicked.connect(signup_page_one)

        # get second register info and all user detail
        def signup_page_two():
            if sign_up_logic_class.check_Signup_page_two_fields():

                register_user_email = self.EmailField_2.text()
                print("helo")
                register_otp_class.sendOtp(register_user_email)
                print("scond")
                self.AuthenticationMenu.setCurrentWidget(self.RegistrationOTP)
                print("dfsf")

        self.SignUpButton_2.clicked.connect(signup_page_two)

        'Registration email verification'
        def register_confirm_otp():
            entered_otp = self.OTPInputField_3.text()
            if entered_otp != "" and len(entered_otp) == 7:
                if entered_otp == register_otp_class.get_Otp():
                    SignUp_db.Add_user_information()
                    SignUp_db.add_user_address()

                    sign_up_logic_class.input_field_clear()

                    self.AuthenticationMenu.setCurrentWidget(self.LoginPage)

        self.RegisterOTP_Btn.clicked.connect(register_confirm_otp)




        """ -------------- Fogotten password --------------"""
        # OTP class
        password_Otp_class = Otp()

        # function to generate send otp to user email
        def send_otp():
            otp_user_email = self.ResetEmailInputField.text()
            if otp_user_email != "":
                if SignUp_db.check_user_email(otp_user_email):
                    password_Otp_class.sendOtp(otp_user_email)
                    self.ResetEmail_Btn.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.PasswordResetOTP))

                else:
                    print("The user doesn't exist")
            else:
                print("field is empty")
        self.ResetEmail_Btn.clicked.connect(send_otp)

        # function to verify verify otp
        def confirm_OTP():
            generated_otp =password_Otp_class.get_Otp()
            User_input_otp = self.OTPInputField_2.text()

            if User_input_otp != "":
                if generated_otp == User_input_otp:
                    self.Otp_Btn_2.clicked.connect(lambda: self.AuthenticationMenu.setCurrentWidget(self.PasswordResetNewPassword))

                else:
                    print("Wrong Otp")

            else:
                print("Field Empty")

        self.Otp_Btn_2.clicked.connect(confirm_OTP)

        # function to reset password
        def set_new_user_password():
            reset_password = self.resetPasswordInputField.text()
            confirm_reset_password =self.ResetConfirmPasswordInputField.text()
            otp_email = self.ResetEmailInputField.text()
            if reset_password != "" and confirm_reset_password != "":
                if confirm_reset_password == reset_password:
                    SignUp_db.update_password(otp_email,reset_password)
                    password_recovery_ui.clear_password_recovery_fields()
                    self.AuthenticationMenu.setCurrentWidget(self.LoginPage)
                else:
                    print("the password doesn't match")
            else:
                print("new password field empty")

        self.PasswordReset_Btn.clicked.connect(set_new_user_password)

        self.show()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ui = Login_Page()

    sys.exit(app.exec_())

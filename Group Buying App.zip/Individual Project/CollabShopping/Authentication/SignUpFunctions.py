from PyQt5 import QtCore, QtGui, QtWidgets
import re
from PyQt5.QtWidgets import QButtonGroup


class SignUpUiFunctions:
    def __init__(self, ui):
        self.ui = ui

    def apply_all_restriction(self):
        self.name_restrict()
        self.password_restrict()
        self.Dob_restrict()
        self.address_restrict()
        self.check_box_restrict()

    def name_restrict(self):
        regx = QtCore.QRegExp("[a-zA-Z ]{200}")
        validator = QtGui.QRegExpValidator(regx)
        self.ui.NameField.setValidator(validator)
        self.ui.SurNameField.setValidator(validator)

    def password_restrict(self):
        self.ui.PasswordField_.setEchoMode(QtWidgets.QLineEdit.Password)
        self.ui.PasswordField.setEchoMode(QtWidgets.QLineEdit.Password)
        self.ui.ConfirmPassword_Field.setEchoMode(QtWidgets.QLineEdit.Password)

    def Dob_restrict(self):
        regx = QtCore.QRegExp("[0-9]{2}")
        validator = QtGui.QRegExpValidator(regx)
        self.ui.DOBDate.setValidator(validator)
        self.ui.DOBDateMonth.setValidator(validator)
        self.ui.DOBYear.setValidator(validator)

    def check_box_restrict(self):
        self.ui.group = QButtonGroup()
        self.ui.group.addButton(self.ui.MaleCheckBox)
        self.ui.group.addButton(self.ui.FemaleCheckBox)
        self.ui.group.setExclusive(True)

    def address_restrict(self):
        regx = QtCore.QRegExp('[a-zA-Z0-9]+')
        validator = QtGui.QRegExpValidator(regx)
        self.ui.FlatNumberField.setValidator(validator)
        self.ui.PostCodeField.setValidator(validator)

        regx2 = QtCore.QRegExp("[a-zA-Z]{300}")
        validator2 = QtGui.QRegExpValidator(regx2)
        self.ui.StreetNameField.setValidator(validator2)
        self.ui.CityField.setValidator(validator2)


class SignUpLogicalFunctions:
    def __init__(self, ui):
        self.ui = ui

    def check_Signup_page_one_fields(self):

        input_name = self.ui.NameField.text()
        input_surname = self.ui.SurNameField.text()
        input_email_address = self.ui.EmailField_2.text()
        input_password = self.ui.PasswordField_.text()
        input_confirm_password = self.ui.ConfirmPassword_Field.text()
        input_dob_date = self.ui.DOBDate.text()
        input_dob_month = self.ui.DOBDateMonth.text()
        input_dob_name = self.ui.DOBYear.text()
        input_male_check_box = self.ui.MaleCheckBox.isChecked()
        input_female_check_box = self.ui.FemaleCheckBox.isChecked()

        if not (self.check_filed_empty(input_name, input_surname, input_email_address, input_password, input_confirm_password, input_dob_date,
                                       input_dob_month,input_dob_name, input_male_check_box, input_female_check_box
                                       )):
            print("empty input fields")
            return False

        if not (self.check_email_is_valid(input_email_address)):
            print("email")
            return False

        if not(self.check_password_strength(input_password)):
            print("password")
            return False

        if not(self.check_field_match(input_password,input_confirm_password)):
            print("password not match")
            return False


        return True

    def get_field(self,field):
        return self.ui.field.text()


    def check_Signup_page_two_fields(self):
        input_flat_no = self.ui.FlatNumberField.text()
        input_street_name= self.ui.StreetNameField.text()
        input_city = self.ui.CityField.text()
        input_post_code = self.ui.PostCodeField.text()
        input_terms = self.ui.termsField.isChecked()

        if not (self.check_address_field(input_flat_no,input_street_name,input_city,input_post_code,input_terms)):
            print("field empty")
            return False

        return True

    def check_email_is_valid(self, email):
        if "@" in email:
            return True
        return False

    def check_filed_empty(self, name, sur_name, email, password,confirm_password, date, month, year,male_check_box,female_check_box):
        if (len(name) == 0 or len(sur_name) == 0 or len(email) == 0 or len(password) == 0 or len(confirm_password) == 0
            or len(date) == 0 or len(month) == 0 or len(year) == 0) or (male_check_box== False and female_check_box == False):
                return False
        return True

    def check_password_strength(self, password):
        if len(password) < 7:
            return False

        # Check for special character, number, uppercase and lowercase
        pattern = r'^(?=.*[!@#$%^&*()_+\-\[\]{};:\|,.<>\/?])(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z]).+$'
        return bool(re.match(pattern, password))

    def check_field_match(self, field1, field2):
        if field1 != field2:
            return False
        return True

    def check_address_field(self, flat_no, street_name, city, post_code,term_check_box):
        if len(flat_no) == 0 or len(street_name) == 0 or len(city) == 0 or len(post_code) == 0 or term_check_box == False :
            return False
        return True

    "Clear input field for sign up page"
    def input_field_clear(self):

        self.ui.NameField.clear()
        self.ui.SurNameField.clear()
        self.ui.EmailField_2.clear()
        self.ui.PasswordField_.clear()
        self.ui.ConfirmPassword_Field.clear()
        self.ui.DOBDate.clear()
        self.ui.DOBDateMonth.clear()
        self.ui.DOBYear.clear()

        self.ui.FlatNumberField.clear()
        self.ui.StreetNameField.clear()
        self.ui.CityField.clear()
        self.ui.PostCodeField.clear()



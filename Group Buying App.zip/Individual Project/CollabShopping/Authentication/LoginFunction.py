from db_connection import DB
class LoginPageFunctions:
    def __init__(self,ui):
        self.db = DB()
        self.ui = ui

    def check_field(self):
        email = self.ui.UserNameField.text()
        password = self.ui.PasswordField.text()

        if len(email) ==0 or len(password)==0:
            return False
        return True


    def check_sign_in_details(self):
        email = self.ui.UserNameField.text()
        password = self.ui.PasswordField.text()
        stmt ="Select Password FROM UserInformation WHERE EmailAddress ='{}' AND Password ='{}';".format(email,password)
        self.db.execute(stmt)
        result = self.db.fetch_all()
        if len(result) == 1:
            return True
        return False



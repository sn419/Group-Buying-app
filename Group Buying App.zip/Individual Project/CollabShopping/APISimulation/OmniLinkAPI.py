from flask import Flask, jsonify, request, abort
import pandas as pd

app = Flask(__name__)
df = pd.read_excel('OmniLink.xlsx')


@app.route('/search', methods=['GET'])
def search():
    products = []
    for index, row in df.iterrows():
        product = {
            'seller_id': row['Seller_id'],
            'product_id': row['Product_id'],
            'name': row['Name'],
            'Price': row['Price'],
            'category': row['Category'],
            'quantity': row['Quantity'],
            'discount': row['Discount'],
            'description': row['Description'],
            'brand': row['Brand'],
            'rating': row['Rating']

        }
        products.append(product)

    # return the list of products as a JSON object
    return jsonify({'products': products})


@app.route('/product_quantity', methods=['GET'])
def product_quantity():
    product_id = int(request.args.get("ProductId"))
    filtered_df = df[df['Product_id'] == product_id]
    if len(filtered_df) == 0:
        return jsonify({'ProductId':'False'})

    value = int(filtered_df['Quantity'].values[0])
    return jsonify({'ProductQuantity': value})


@app.route('/seller_id', methods=['GET'])
def seller_id():
    filtered_df = [df['Seller_id']]
    id = filtered_df[0][0]

    return jsonify({'SellerId': '{}'.format(id)})

@app.route('/reduce_product_quantity', methods=['POST'])
def reduce_product_quantity():

    product_id = int(request.args.get("ProductId"))
    product_quantity = int(request.args.get("ProductQuantity"))
    filtered_df = df[df['Product_id'] == product_id]

    if len(filtered_df) == 0:
        return jsonify({'ProductId:': 'False'})

    quantity = filtered_df['Quantity'].values[0]

    if product_quantity < 0 :
        return jsonify({'Quantity:': 'invalid'})

    if product_quantity > int(quantity):
        return jsonify({'Quantity:':'insufficient'})

    new_quantity = int(quantity) - product_quantity

    df.loc[df['Product_id'] == product_id, 'Quantity'] = new_quantity

    df.to_excel('OmniLink.xlsx', index=False)

    return jsonify({"Message": "Quantity updated successfully"}),200

@app.route('/product_price', methods=['GET'])
def product_price():
    product_id = int(request.args.get("ProductId"))
    filtered_df = df[df['Product_id'] == product_id]

    if len(filtered_df) == 0:
        return jsonify({'ProductId:': 'False'})

    value = int(filtered_df['Price'].values[0])

    return jsonify({'ProductPrice':value})

@app.route('/update_rating', methods=['POST'])
def update_rating():
    # Get product ID and rating from client side
    product_id = int(request.args.get('ProductId'))
    rating = int(request.args.get('Rating'))

    current_rate = rating / 100

    current_rate += df.loc[df['Product_id'] == product_id, 'Rating'].values[0]

    # Update rating in Excel file
    df.loc[df['Product_id'] == product_id, 'Rating'] = current_rate

    df.to_excel('BrightBazaar.xlsx', index=False)

    return jsonify({"Message": "Rating updated successfully"}), 200


if __name__ == "__main__":
    app.run(debug=True,host= 'localhost',port =8002)

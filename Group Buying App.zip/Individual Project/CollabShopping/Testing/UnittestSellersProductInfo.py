import unittest

from MainApp.SellersProductsInfo import Sellers

class TestSellerProductInfo(unittest.TestCase):
    def __init__(self):
        super().__init__()
        self.sellers = Sellers()

    def test_sellers_unified_products(self):
        self.sellers.get_all_sellers()

        expected_result = 150
        result = self.sellers.get_all_sellers()
        self.assertEqual(expected_result,result)

import unittest
from Authentication.SignUpFunctions import SignUpLogicalFunctions

class TestSignUpFunctions(unittest.TestCase):
    def __init__(self):
        super().__init__()
        userinterface = None
        self.sign_up_functions = SignUpLogicalFunctions(userinterface)

    def test_Email(self):
        email = "sanau@gmail.com"

        expected_result = True
        result = self.sign_up_functions.check_email_is_valid(email)
        self.assertEqual(expected_result,result)

    def test_password_strength(self):
        password ="jdfjk432W"

        expected_result = False
        result = self.sign_up_functions.check_password_strength(password)
        self.assertEqual(expected_result,result)

    def test_field_match(self):
        field1 = "Wafddf32!"
        field2 ="Wafddf32!"

        expected_result = True
        result = self.sign_up_functions.check_field_match(field1,field2)
        self.assertEqual(expected_result,result)

    def test_address_field(self):
        flat_no = '14'
        street_name = ""
        city = 'london'
        post_code = 'SE8 4LS'
        term_check_box = "Yes"

        expected_result = False
        result = self.sign_up_functions.check_address_field(flat_no,street_name,city,post_code,term_check_box)
        self.assertEqual(expected_result,result)

import unittest
from MainApp.SellerInfo import Seller
class TestSeller(unittest.TestCase):
    def __init__(self):
        super().__init__()
        self.seller_id = 987436712
        self.api = 'http://localhost:8000'
        self.seller = Seller("brightbazaar",self.seller_id,self.api)

    def test_product_info(self):

        expected_result = 50
        result = self.seller.products_info()
        self.assertEqual(expected_result,result)


    def test_product_quantity(self):
        product_id = 765450415
        quantity = 500
        expected_quantity = False
        result = self.seller.check_product_quantity(product_id,quantity)
        self.assertEqual(expected_quantity, result)


    def test_get_product_price(self):
        product_id = 765450415

        expected_price = 12
        result = self.seller.get_product_price(product_id)
        self.assertEqual(expected_price,result)


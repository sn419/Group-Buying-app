import unittest
from db_connection import DB
class TestLogin(unittest.TestCase):
    def setup(self):
        self.db = DB()

    def check_sign_in_details(self):
        email = "ajaz.noorzai@gmail.com "
        password = "Wardak54!"
        stmt ="Select Password FROM UserInformation WHERE EmailAddress ='{}' AND Password ='{}';".format(email,password)
        self.db.execute(stmt)
        result = self.db.fetch_all()

        expected_outcome = 1
        result = len(result)
        self.assertEqual(result,expected_outcome)
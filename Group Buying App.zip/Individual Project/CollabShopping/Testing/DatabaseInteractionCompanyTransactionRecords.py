import unittest
from db_connection import DB
from MainApp.CompanyTransaction import CompanyTransactionsRecords
import string
import random

class TestCompanyTransactionsRecords(unittest.TestCase):
    def setUp(self):
        self.db = DB()  # initialize a test database connection
        self.c = CompanyTransactionsRecords()

    def test_get_transaction_id(self):
        expected_length = 8
        result = len(self.c.generate_transaction_id())
        self.assertEqual(result, expected_length)

    def test_get_transaction_record(self):
        order_id = 12545344
        seller_id = 43254324
        product_id = 3245535
        quantity = 50
        cost = 100

        self.c.save_transaction_record(self.db, order_id, seller_id, product_id, quantity, cost)

        expected_amount = 1
        result = len(self.c.get_transaction_record(self.db, order_id))
        self.assertEqual(result, expected_amount)

    def test_delete_transaction_record(self):
        order_id = 12545344

        expected_result = 0
        result = len(self.c.delete_transaction_record(self.db,order_id))
        self.assertEqual(result, expected_result)



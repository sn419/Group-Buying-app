import unittest
from MainApp.MultipleSellers import Sellers
class TestShoppingBasket(unittest.TestCase):
    def setUp(self):
        self.seller_id = 987436712
        self.product_id = 7654504
        self.total_quantity = 10
        self.sellers = Sellers()
        self.current_seller = self.sellers.get_seller(self.seller_id)
        self.unit_price = 0
        self.total = 0

    def get_sub_total(self):
        expected_sub_total = 12 * self.total_quantity
        sub_total_cost = (self.current_seller.get_product_price(self.product_id)) * self.total_quantity
        self.assertEqual(sub_total_cost, expected_sub_total)

    def set_total(self):
        expect_total = 12 * self.unit_price
        self.total = self.current_seller.get_shopping_cart_cost(self.product_id, self.total_quantity)
        self.assertEqual( self.total, expect_total)

    def update_total(self, amount):
        expected_unit_price = 12
        self.total = amount
        self.unit_price = amount / self.total_quantity
        self.assertEqual( expected_unit_price, self.unit_price)



import unittest
from Authentication.AuthenticationSQL.SignUpDB import SignUpDb
from db_connection import DB

class TestSignUpDb(unittest.TestCase):
    def setup(self):
        self.db = DB()
        self.sign_up = SignUpDb(self.db)

        def test_get_user_email():
            email = "ajaz.noorzai@gmail.com"
            result = self.sign_up.check_user_email(email)
            self.assertEqual(len(result) , 1)

            self.assertEqual(email, result)

        def test_add_user_information():
            self.sign_up.Add_user_information()
            self.sign_up.add_user_address()






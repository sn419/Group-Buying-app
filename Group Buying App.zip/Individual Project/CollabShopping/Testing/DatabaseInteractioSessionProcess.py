import unittest
from db_connection import DB
from MainApp.Session import Session
class TestSession(unittest.TestCase):

    def setup(self):
        self.db = DB()
        self.session = Session()
        self.seller_id = 134345
        self.product_id = 434556

    def get_product_update(self):
        sql_stmt = "SELECT Quantity FROM ActiveSessions WHERE SellerId = %s AND ProductId = %s"
        values =(self.seller_id,self.product_id)
        self.db.execute(sql_stmt, values)
        amount =self.db.fetch_all()
        if len(amount) > 0:
           return amount[0]
        else:
            return -1


    def test_add_session(self):
        self.session.add_session(self.db,self.seller_id,self.product_id)

        expected_result = 0
        result = self.get_product_update()
        self.assertEqual(expected_result, result)

    def test_update_session(self):
        amount = 15
        self.session.update_session(self.db,self.seller_id,self.product_id,amount)

        expected_result = amount
        result = self.get_product_update()
        self.assertEqual(expected_result, result)






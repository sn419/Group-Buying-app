import mysql.connector


class DB:
    def __init__(self):

         self.conn = mysql.connector.connect(
                host='collab.c4vpnxtxzdfp.us-east-2.rds.amazonaws.com',
                user='admin',
                password='4897ryj7tyA4',
                database="unify",
            )

         self.cursor = self.conn.cursor()

    def execute(self, query, params=None):
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
        except mysql.connector.Error as e:
            print("Mysql Error: {} ".format(e))




    def fetch_all(self):
            return self.cursor.fetchall()

    def db_commit(self):
        self.conn.commit()

import keyring
class UserSession:

    def create_session(self,email,password):
        keyring.set_password('Unify', '{}'.format(email), '{}'.format(password))


    def destroy_session(self,email):
        keyring.delete_password("Unify", "{}".format(email))


    def get_user_email(self):
        try:
            credentials = keyring.get_credential("Unify", None)
            username = credentials.username
            return username
        except:
            return None

    def get_password(self):
        try:
            credentials = keyring.get_credential("Unify", None)
            password = credentials.password
            return password
        except:
            return None

    # needs to be finished
    def set_email(self,input_email):
        self.username = input_email




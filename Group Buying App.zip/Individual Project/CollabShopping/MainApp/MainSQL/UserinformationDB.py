

class UserDB:
    def __init__(self,db):
        self.db = db

    def get_name(self, email):
        stmt = "SELECT Name FROM UserInformation WHERE EmailAddress= '{}';".format(email)
        self.db.execute(stmt)
        result = self.db.fetch_all()
        self.db.db_commit()
        print(result)
        if len(result) > 0:
            return result[0][0]

    def get_password(self, email):
        stmt = "SELECT Password FROM UserInformation WHERE EmailAddress= '{}';".format(email)
        self.db.execute(stmt)
        result = self.db.fetch_all()
        self.db.db_commit()

        return result[0][0]

    def update_passeword(self, user_password,email):
        stmt = "UPDATE UserInformation SET Password ='{}' WHERE EmailAddress= '{}';".format(user_password, email)
        self.db.execute(stmt)
        self.db.db_commit()

    def update_new_user_information(self, email, new_email, name, surname):
        stmt = "UPDATE UserInformation SET Name ='{}',SurName ='{}',EmailAddress= '{}' WHERE EmailAddress = '{}';".format(name,surname,new_email,email)
        self.db.execute(stmt)
        self.db.db_commit()

    def update_new_address(self, email, flat_no, street_name, city, post_code):
        stmt = "UPDATE UserAddress SET FlatNo ='{}',StreetName ='{}',City='{}',PostCode = '{}'  WHERE EmailAddress = '{}';".format(flat_no,street_name,city,post_code,email)
        self.db.execute(stmt)
        self.db.db_commit()


    def verify_password(self, email, password):
        stmt = "SELECT Password FROM UserInformation WHERE EmailAddress= '{}';".format(email)
        self.db.execute(stmt)
        result = self.db.fetch_all()
        self.db.db_commit()

        return result[0][0] == password

    def get_surname(self, email):
        stmt = "SELECT SurName FROM UserInformation WHERE EmailAddress= '{}';".format(email)
        self.db.execute(stmt)
        result = self.db.fetch_all()
        self.db.db_commit()

        return result[0][0]

    def get_address(self, email):
        stmt = "SELECT FlatNo, StreetName, City, PostCode FROM UserAddress WHERE EmailAddress= '{}';".format(email)
        self.db.execute(stmt)
        result = self.db.fetch_all()
        self.db.db_commit()

        return result[0]

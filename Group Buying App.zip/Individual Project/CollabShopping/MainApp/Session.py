import random
import datetime
import keyring
class Session:

    def add_session(self, db, seller_id, product_id):
        id = int(''.join(str(random.randint(0, 9)) for _ in range(9)))

        # Create a new session
        current = datetime.datetime.now()
        expired = int(current.timestamp()/60)
        expiry_time = expired * 5
        print(id,seller_id,product_id,0,expiry_time)

        # Add the session to the active session table
        try:
            sql_stmt = "INSERT INTO ActiveSessions(SessionId,SellerId,ProductId,Quantity,SessionExpire) VALUES (%s, %s, %s, %s, %s)"
            values =( id, seller_id, product_id, 0, expiry_time)
            db.execute(sql_stmt, values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)


    def check_session(self,db,seller_id,product_id):
        try:
            sql_stmt = "SELECT * FROM ActiveSessions WHERE SellerId = %s AND ProductId = %s"
            values = (seller_id, product_id)
            db.execute(sql_stmt,values)
            result = db.fetch_all()
            if len(result) !=0:
                return False
            else:
                return True
        except Exception as e:
            print("Error deleting record:", e)

    def delete_session(self, db, session_id):
        # delete the session_id with the id
        pass

    def update_session(self, db, seller_id, product_id, quantity):
        # add the details to the active session

        try:
            sql_stmt = " UPDATE ActiveSessions SET Quantity =Quantity + %s WHERE SellerId = %s AND ProductId = %s"
            values = (quantity,seller_id, product_id)
            db.execute(sql_stmt,values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)


        credentials = keyring.get_credential("Unify", None)
        user_id = credentials.username

        if (self.check_user_session(db, user_id, seller_id,product_id)) == 0:
            self.add_user_session(db, user_id, seller_id,product_id,quantity)
        else:
            self.update_user_session(db, user_id, seller_id,product_id,quantity)

    def add_user_session(self, db,user_id, seller_id, product_id, quantity):
        try:
            sql_stmt = "INSERT INTO UserActiveSession(UserId,SellerId,ProductId,Quantity)VALUES (%s, %s, %s, %s)"
            values = (user_id, seller_id, product_id,quantity)
            db.execute(sql_stmt,values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)


    def update_user_session(self,db,user_id,seller_id,product_id,quantity):
        try:
            sql_stmt = " UPDATE UserActiveSession SET Quantity =%s WHERE SellerId = %s AND ProductId = %s AND UserId =%s"
            values = (quantity,seller_id, product_id,user_id)
            db.execute(sql_stmt,values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)



    def check_user_session(self,db,user_id,seller_id,product_id):
        try:
           sql_stmt = "SELECT * FROM UserActiveSession WHERE SellerId = %s AND ProductId = %s AND UserID = %s;"
           values = (seller_id, product_id,user_id)
           db.execute(sql_stmt,values)
           result = db.fetch_all()
           return len(result)
        except Exception as e:
            print("Error deleting record:", e)




#keyring.set_password('Unify', '{}'.format('sn@gmail.com'), '{}'.format('wardak123'))
#session = Session()

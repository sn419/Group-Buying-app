from PyQt5 import QtCore, QtGui, QtWidgets

class CheckCardUi:

    def __init__(self, ui):
        self.ui = ui
        self.set_ui_restriction()

    "Set ui restriction to bank card "
    def set_ui_restriction(self):

        """ Bank card Number restrictions """
        regx = QtCore.QRegExp("[a-zA-Z ]{200}")
        validator = QtGui.QRegExpValidator(regx)
        self.ui.BankCardNameInput.setValidator(validator)

        """bank card number ui restriction"""
        regx = QtCore.QRegExp("[0-9]{12}")
        validator = QtGui.QRegExpValidator(regx)
        self.ui.BankCardNumberInput.setValidator(validator)

        """Bank card expiry  field ui restriction"""
        regx = QtCore.QRegExp("[0-9]{5}")
        validator = QtGui.QRegExpValidator(regx)
        self.ui.BankCardValidInput.setValidator(validator)

        """Bank card security field ui restriction"""
        regx = QtCore.QRegExp("[0-9]{4}")
        validator = QtGui.QRegExpValidator(regx)
        self.ui.BankCardCvvInput.setValidator(validator)



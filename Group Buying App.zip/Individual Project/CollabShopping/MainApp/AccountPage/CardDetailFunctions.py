from PyQt5.QtGui import QRegExpValidator
from MainApp.MainAppUi.menuBar import *

class CheckCardDetails:
    def __init__(self,ui):
        self.ui = ui

    def check_al_card_details(self):
        pass

    def check_card_name(self):
        pass

    def check_card_number(self):
        card_number = self.main.BankCardNumberInput.text()

        pass

    def check_card_expiry(self):
        pass

    def check_card_cvv(self):
        pass


class CardFunctionsUiRestrictions:
    def __init__(self,MainWindow):

        self.Main = MainWindow

    def set_all_card_restriction(self):
        self.set_card_name_restriction()
        self.set_card_number_restriction()
        self.set_card_expiry()
        self.set_card_cvv()


    def set_card_name_restriction(self):
        regx  = QtCore.QRegExp("[a-zA-Z ]{200}")
        validator = QtGui.QRegExpValidator(regx)
        self.Main.BankCardNameInput.setValidator(validator)

    def set_card_number_restriction(self):
        regx  = QtCore.QRegExp("[0-9]{30}")
        validator = QtGui.QRegExpValidator(regx)
        self.Main.BankCardNumberInput.setValidator(validator)


    def set_card_expiry(self):
        regx  = QtCore.QRegExp("[0-9]{5}")
        validator = QtGui.QRegExpValidator(regx)
        self.Main.BankCardValidInput.setValidator(validator)

    def set_card_cvv(self):
        regx  = QtCore.QRegExp("[0-9]{3}")
        validator = QtGui.QRegExpValidator(regx)
        self.Main.BankCardCvvInput.setValidator(validator)






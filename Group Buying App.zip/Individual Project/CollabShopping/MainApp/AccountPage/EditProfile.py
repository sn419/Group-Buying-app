from PyQt5 import QtWidgets


class EditProfileUi:
    def __init__(self, ui, db, userInfo):
        self.ui = ui
        self.db = db
        self.userInfo = userInfo

    def fill_edit_profile_fields(self):
        self.email = self.userInfo.get_user_email()

        # get the name
        self.ui.NameFrameInput_Box.setText(self.db.get_name(self.email))

        # get surname
        self.ui.surnameFrameInput_Box.setText(self.db.get_surname(self.email))

        #  get email
        self.ui.EmailFrameInput_Box.setText(self.email)

        # get the passwords
        self.ui.OldPasswordFrameInput_Box.setEchoMode(QtWidgets.QLineEdit.Password)
        self.ui.NewPasswordFrameInput_Box.setEchoMode(QtWidgets.QLineEdit.Password)

        fetch_user_address = self.db.get_address(self.email)
        flatno = fetch_user_address[0]
        streetName = fetch_user_address[1]
        city = fetch_user_address[2]
        postcode = fetch_user_address[3]

        self.ui.AddressFrameFirstLine.setText(flatno)
        self.ui.AddressFrameSecondLine.setText(streetName)
        self.ui.AddressFrameThirdLine.setText(city)
        self.ui.AddressFrameFourthLine.setText(postcode)


    def update_edit_profile_fields(self):
        name = self.ui.NameFrameInput_Box.text()
        surname = self.ui.surnameFrameInput_Box.text()
        email = self.ui.EmailFrameInput_Box.text()
        old_password = self.ui.OldPasswordFrameInput_Box.text()
        new_password = self.ui.NewPasswordFrameInput_Box.text()
        flatno = self.ui.AddressFrameFirstLine.text()
        streetname = self.ui.AddressFrameSecondLine.text()
        city = self.ui.AddressFrameThirdLine.text()
        postcode = self.ui.AddressFrameFourthLine.text()
        if self.check_all_field_filled(name,surname,email,flatno, streetname, city, postcode):
            old_email = self.userInfo.get_user_email()
            self.db.update_new_user_information(old_email, email, name, surname)
            self.db.update_new_address(email,flatno,streetname,city,postcode)



    def check_password_match(self,old_password):
        if old_password == self.db.get_password(self.email):
            return True
        return False

    def check_all_field_filled(self,name,surname,email,flatno,streetname,city,postcode):

        if (len(name) != 0 or len(surname) != 0 or len(email) != 0  or len(flatno) != 0 or len(streetname) != 0 or len(city) != 0 or len(postcode) != 0 ):
            return True
        else:
            print("you edit profile form is incomplete")
        return False

    def check_edit_profile_password_fields(self,email,old_password,new_password):

         if len(old_password) > 0 and (len(new_password) > 0):
           if self.check_password_match(old_password):
               self.db.update_passeword(email,new_password)
               return True
           else:
               print("the old password doesn't match")
         else:
            print("incorrect password")






















import random
import string


class CardsWalletDB:
    def __init__(self, db):
        self.db = db

    def add_card(self, username, name, card_number, valid, cvv):
        try:
            characters = string.ascii_letters + string.digits
            card_identity = ''.join(random.choice(characters) for _ in range(8))

            sql_stmt = "INSERT INTO UserBankCardsDetail(EmailAddress,Name,CardNumber,Valid,CVV,Balance,Card_Identity)VALUES (%s, %s, %s,%s, %s, %s,%s)"
            values = (username, name, card_number, valid, cvv, 5000.00,card_identity)
            self.db.execute(sql_stmt, values)
            self.db.db_commit()
        except Exception as e:
            print("Error adding record:", e)

    def get_user_cards(self, username):
        try:
            query = "SELECT Card_Identity,Name,CardNumber,Valid FROM UserBankCardsDetail WHERE  EmailAddress = %s "
            values = (username,)
            self.db.execute(query, values)
            result = self.db.fetch_all()
            return result
        except Exception as e:
            print("Error loading record:", e)

    def delete_card(self, username, card_identity):
        try:
            sql_stmt = "DELETE FROM UserBankCardsDetail WHERE EmailAddress = %s AND Card_Identity = %s"
            values = (username, card_identity)
            self.db.execute(sql_stmt, values)
            self.db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)

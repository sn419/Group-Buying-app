from PyQt5 import QtWidgets, QtCore
from PyQt5.QtCore import Qt
from PyQt5.QtCore import QSize
from PyQt5.QtWidgets import QMainWindow, QFrame, QVBoxLayout, QLabel,QHBoxLayout

class CardWalletUi(QMainWindow):
    def __init__(self, ui):
        super().__init__()
        self.ui = ui
        self.frames = {}
        self.selected_frame = None

    def get_card_detail(self):
        card_name = self.ui.BankCardNameInput.text()
        card_number = self.ui.BankCardNumberInput.text()
        card_expiry_date = self.ui.BankCardValidInput.text()
        card_security_code = self.ui.BankCardCvvInput.text()

        return (card_name,card_number,card_security_code,card_expiry_date)


    def delete_card(self):
        if self.selected_frame is not None:
            frame_name = self.frames[self.selected_frame]
            self.frames.pop(self.selected_frame)
            self.ui.verticalLayout_59.removeWidget(self.selected_frame)
            self.selected_frame.deleteLater()
            self.selected_frame = None

            return frame_name

    def get_user_cards(self, Cards):
        for i in range(len(Cards)):

            self.load_user_cards(Cards[i][0], Cards[i][1], Cards[i][2], Cards[i][3])

    def load_user_cards(self, object_name, card_holder_name, card_number, expiry_date):

            self.CardDetailFrame = QtWidgets.QFrame(self.ui.UserCards)
            sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Preferred)
            sizePolicy.setHorizontalStretch(0)
            sizePolicy.setVerticalStretch(0)
            sizePolicy.setHeightForWidth(self.CardDetailFrame.sizePolicy().hasHeightForWidth())
            self.CardDetailFrame.setSizePolicy(sizePolicy)
            self.CardDetailFrame.setMinimumSize(QtCore.QSize(1, 150))
            self.CardDetailFrame.setMaximumSize(QtCore.QSize(16777215, 150))
            self.CardDetailFrame.setStyleSheet("background-color: rgb(0, 0, 0);\n"
                                               "border-radius:15px;")

            frame_layout = QVBoxLayout()
            frame_layout.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

            # Card Number Label
            card_number_label = QLabel()
            card_number_label.setStyleSheet("font-size: 20px; font-weight: bold; ")
            card_number_label.setText("XXXX XXXX XXXX {}".format(card_number[-4:]))
            frame_layout.addWidget(card_number_label)

            # Card Holder Name and Card Validity Labels
            card_info_layout = QHBoxLayout()
            card_holder_label = QLabel()
            card_holder_label.setStyleSheet("font-size: 16px; ")
            card_holder_label.setText("Card Holder:")
            card_validity_label = QLabel()
            card_validity_label.setStyleSheet("font-size: 16px; ")
            card_validity_label.setText("Card Validity:")
            card_info_layout.addWidget(card_holder_label)
            card_info_layout.addWidget(card_validity_label)
            frame_layout.addLayout(card_info_layout)

            # Card Holder Name and Card Validity Detail Labels
            card_detail_layout = QHBoxLayout()
            card_holder_detail_label = QLabel()
            card_holder_detail_label.setStyleSheet("font-size: 16px; ")
            card_holder_detail_label.setText("{}".format(card_holder_name))
            card_validity_detail_label = QLabel()
            card_validity_detail_label.setStyleSheet("font-size: 16px; ")
            card_validity_detail_label.setText("{}".format(expiry_date))
            card_detail_layout.addWidget(card_holder_detail_label)
            card_detail_layout.addWidget(card_validity_detail_label)
            frame_layout.addLayout(card_detail_layout)

            # Set frame layout alignment
            frame_layout.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            self.CardDetailFrame.setLayout(frame_layout)
            self.frames[self.CardDetailFrame] = object_name

            self.CardDetailFrame.installEventFilter(self)
            self.ui.verticalLayout_59.addWidget(self.CardDetailFrame, 0, QtCore.Qt.AlignTop)
    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.MouseButtonPress:
            if obj in self.frames.keys():
                print("clicked")
                self.selected_frame = obj
            return False
        return super().eventFilter(obj, event)

    def clear_wallet(self):
        for frame in self.frames.keys():
            self.ui.verticalLayout_59.removeWidget(frame)
            frame.setParent(None)
        self.frames = {}




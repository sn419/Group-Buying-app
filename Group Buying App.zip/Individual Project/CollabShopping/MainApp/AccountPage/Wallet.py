from MainApp.AccountPage.WalletDB import CardsWalletDB
from MainApp.AccountPage.WalletUi import CardWalletUi


class CardsWallet:

    def __init__(self, db, ui):
        self.card_wallet_db = CardsWalletDB(db)
        self.card_wallet_ui = CardWalletUi(ui)


    def load_user_cards(self, username):
        card_info = self.card_wallet_db.get_user_cards(username)
        self.card_wallet_ui.get_user_cards(card_info)

    def delete_user_card(self, username):
        card = self.card_wallet_ui.delete_card()
        self.card_wallet_db.delete_card(username, card)

    def add_card(self, username):
        bank_card_details =  self.card_wallet_ui.get_card_detail()
        self.card_wallet_db.add_card(username,bank_card_details[0],bank_card_details[1],bank_card_details[2],bank_card_details[3])
        self.clear_user_wallet()
        self.load_user_cards(username)

    def clear_user_wallet(self):
        self.card_wallet_ui.clear_wallet()


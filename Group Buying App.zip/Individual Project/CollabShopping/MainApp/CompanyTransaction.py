import random, string
from db_connection import DB

class CompanyTransactionsRecords:
    def get_transaction_id(self):
            return self.generate_transaction_id()

    def generate_transaction_id(self):
        characters = string.ascii_uppercase + string.ascii_lowercase + string.digits
        code = ''.join(random.choice(characters) for i in range(8))
        return code

    def save_transaction_record(self,db, order_id, seller_id, product_id, quantity, cost):
        try:
            sql_stmt = "INSERT INTO CompanyTransactionRecords(TransactionId,SellerId,ProductId,Quantity,TotalAmount) VALUES (%s, %s, %s, %s, %s)"
            values =(order_id,seller_id,product_id,quantity,cost)
            db.execute(sql_stmt, values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)

    def delete_transaction_record(self,db, order_id):
        try:
            sql_stmt = "DELETE FROM CompanyTransactionRecords WHERE TransactionId = %s "
            values = (order_id,)
            db.execute(sql_stmt, values)
            db.db_commit()
        except Exception as e:
            print(e)



    def get_transaction_record(self,db,order_id):
        try :
            query = "SELECT * FROM CompanyTransactionRecords WHERE TransactionId = %s"
            values = (order_id,)
            db.execute(query, values)
            result = db.fetch_all()
            return result
        except Exception as e:
            print("Error deleting record:", e)


import datetime
class CompanyCommissionRecords:

    def save_commision_record(self, db, order_id,amount):
        date = str(datetime.datetime.today().date())
        try:
            sql_stmt = "INSERT INTO CommissionRecords (TransactionId,Amount,Date)VALUES (%s, %s, %s)"
            values = (order_id, amount, date)
            db.execute(sql_stmt, values)
            db.db_commit()
        except Exception as e:
            print("Error adding record:", e)

    def delete_commission_record(self, db, order_id):
        try:
            sql_stmt = "DELETE FROM CommissionRecords WHERE TransactionId = %s"
            values = (order_id,)
            db.execute(sql_stmt, values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)

    def get_commission_record(self, db, order_id):
        try :
            query = "SELECT * FROM CommissionRecords WHERE  TransactionId = %s "
            values = (order_id,)
            db.execute(query, values)
            result = db.fetch_all()
            print(result)
        except Exception as e:
            print("Error retrieving record:", e)

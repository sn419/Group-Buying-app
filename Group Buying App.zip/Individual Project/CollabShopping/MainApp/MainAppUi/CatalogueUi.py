from PyQt5.QtCore import QSize
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMainWindow, QFrame, QVBoxLayout, QLabel, QPushButton, QHBoxLayout


class ProductsView(QMainWindow):
    def __init__(self, ui,individual_product_view):
        super().__init__()
        self.individual_product_view = individual_product_view
        self.ui = ui
        self.products = None
        self.product_id = None



    def set_product(self, products_info):
        self.products = products_info
        self.product_id = list(products_info)

    def product_info(self, product_amount):
        row_num = product_amount // 4
        if product_amount % 4 != 0:
            row_num += 1

        col_num = 4
        i = 0
        for x in range(1, row_num + 1):
            # columns
            for y in range(0, col_num):
                self.createNewWidgets(x, y, self.product_id[i][0], self.product_id[i][1],
                                      self.products[self.product_id[i]])
                i += 1

            value = product_amount - (x * col_num)
            if value < col_num:
                col_num = value

    def createNewWidgets(self, rowNumber, columNumber, seller_id, product_id, product_detail):
        # CREATE NEW UNIQUE NAMES FOR THE WIDGETS
        newName = "frame" + str(rowNumber) + "_" + str(columNumber)
        print(newName)

        # USE setObjectName() to give your object a new name
        # Create a frame with updated style
        self.frame = QFrame(self.ui.ProductsScrollArea)
        self.frame.setObjectName(newName)
        self.frame.setMinimumSize(QSize(240, 240))
        self.frame.setStyleSheet(
            u"background-color: rgb(3, 61, 100); border: 1px solid #ccc; border-radius: 5px; font-size: 12px;")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        setattr(self.ui, newName, self.frame)

        # Create a vertical layout for the frame
        frame_layout = QVBoxLayout(self.frame)
        frame_layout.setAlignment(Qt.AlignHCenter | Qt.AlignBottom)  # Set alignment to top

        # Create labels to display product information
        product_name_label = QLabel()
        product_name_label.setText("Name: {}".format(product_detail['name']))
        product_name_label.setStyleSheet("font-weight: bold;")
        product_brand_label = QLabel()
        product_brand_label.setText("Brand: {}".format(product_detail['brand']))
        product_price_label = QLabel()
        product_price_label.setText("Price: {}".format(product_detail['Price']))

        # Create a button for product details
        product_detail_btn = QPushButton()
        product_detail_btn.setText("View")
        product_detail_btn.setProperty('sellerid', seller_id)
        product_detail_btn.setProperty('productid', product_id)
        product_detail_btn.setStyleSheet(
            "background-color: #007BFF; color: #fff; padding: 5px 10px; border: none; border-radius: 3px;")
        product_detail_btn.clicked.connect(lambda: self.get_clicked_product_detail())

        # Create a horizontal layout for the button
        button_layout = QHBoxLayout()
        button_layout.addStretch(1)  # Add stretchable space to left align the button
        button_layout.addWidget(product_detail_btn)
        button_layout.addStretch(1)  # Add stretchable space to right align the button

        # Add the button layout to the frame layout
        frame_layout.addLayout(button_layout)
        frame_layout.addWidget(product_name_label)
        frame_layout.addWidget(product_price_label)
        frame_layout.addWidget(product_brand_label)
        frame_layout.addWidget(product_detail_btn)

        # Set the layout of the frame to the created frame layout
        self.frame.setLayout(frame_layout)

        self.ui.gridLayout.addWidget(self.frame, rowNumber, columNumber, 1, 1, Qt.AlignHCenter | Qt.AlignVCenter)


    def get_clicked_product_detail(self):
        sender = self.sender()
        seller_id = sender.property('sellerid')
        product_id = sender.property('productid')
        print("catalogue ui", seller_id, product_id)
        self.individual_product_view.set_product_detail(seller_id, product_id, self.products[(seller_id,product_id)])
        self.individual_product_view.set_product_page_detail()
        self.ui.BrowsePageStackedWidget.setCurrentWidget(self.ui.ProductDetailOuterFrame)


    def clear_product(self):
        while self.ui.gridLayout.count() > 0:
            item = self.ui.gridLayout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.setParent(None)
                widget.deleteLater()

        self.ui.gridLayout.update()

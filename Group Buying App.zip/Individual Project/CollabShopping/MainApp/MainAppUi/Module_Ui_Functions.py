"""change the side menu bar size"""

from PyQt5.QtCore import QPropertyAnimation

class UIFunction:

    def side_menu_toggle(self,Qwindow ,max_width, enable):
        if enable:
            width = Qwindow.Side_Menu.width()
            max_extend = max_width
            standard = 0

            set_width = 0
            if width == 0:
                set_width = max_extend
            else:
                set_width = standard


            # Animation
            Qwindow.animation =  QPropertyAnimation(Qwindow.Side_Menu, b"maximumWidth")
            Qwindow.animation.setDuration(400)
            Qwindow.animation.setStartValue(width)
            Qwindow.animation.setEndValue(set_width)
            Qwindow.animation.start()


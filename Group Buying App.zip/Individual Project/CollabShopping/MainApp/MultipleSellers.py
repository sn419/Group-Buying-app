from MainApp.SellerInfo import Seller
class Sellers:
    def __init__(self):
        self.product_sellers = {}
        self.add_seller()

    def add_seller(self):
        self.product_sellers[987436712] = Seller('BrightBazaar',987436712,'http://localhost:8000')
        self.product_sellers[145786789] = Seller('Emart',145786789,'http://localhost:8001')
        self.product_sellers[132098320] = Seller('OmniLink',132098320,'http://localhost:8002')

    def delete_seller(self, seller_id):
        if seller_id in self.product_sellers:
            self.product_sellers.pop(seller_id)

    def get_seller(self, seller_id):
        if seller_id in self.product_sellers.keys():
            return self.product_sellers[seller_id]

    def is_seller_exist(self, seller_id):
        if seller_id in self.product_sellers:
            return True
        return False

    def get_all_sellers(self):
        return self.product_sellers

from MainApp.Session import Session
from MainApp.MultipleSellers import Sellers

class StitchOrderSystem:
    def __init__(self,db,ui):
        self.db = db
        self.session = Session()
        self.ui = ui
        self.seller_id = None
        self.product_id = None
        self.sellers = Sellers()
        self.product_seller = None

        self.ui.ProductReserve_Btn.clicked.connect(lambda : self.stitch_order())

    def set_reserve_product(self,seller_id,product_id):
        self.seller_id = seller_id
        self.product_id = product_id
        self.product_seller = self.sellers.get_seller(seller_id)

    def stitch_order(self):
        product_quantity = self.ui.ProductReserveQuantityLine.text()

        if product_quantity != "":
            if self.product_seller.check_product_quantity(self.product_id,int(product_quantity)):

                if self.session.check_session(self.db,self.seller_id,self.product_id):

                    self.session.add_session(self.db,self.seller_id,self.product_id)

                self.session.update_session(self.db,self.seller_id,self.product_id,product_quantity)

                self.ui.BrowsePageStackedWidget.setCurrentWidget(self.ui.BrowsePageProductView)
            else:
                "The quantity you reserved is more the inventory you reserved"

        else:
            print("Enter Product quanitity to be reserved")



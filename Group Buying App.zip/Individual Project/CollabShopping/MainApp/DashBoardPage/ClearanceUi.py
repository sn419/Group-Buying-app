from PyQt5.QtCore import QSize
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMainWindow, QFrame, QVBoxLayout, QLabel, QPushButton, QHBoxLayout


class ProductClearanceUi:
    def __init__(self, ui):
        self.ui = ui
        self.products = None
        self.product_id = None

    def set_product(self, products_info):
        self.products = products_info
        self.product_id = list(products_info)

    def product_info(self, product_amount):
        row_num = 2

        col_num = 5
        i = 0
        for x in range(1, row_num + 1):
            # columns
            for y in range(0, col_num):
                self.create_new_clearance_widgets(x, y, self.product_id[i][0], self.product_id[i][1],
                                      self.products[self.product_id[i]])
                i += 1


    def create_new_clearance_widgets(self, rowNumber, columNumber, seller_id,product_id, product_detail):
        # CREATE NEW UNIQUE NAMES FOR THE WIDGETS
        newName = "frame" + str(rowNumber) + "_" + str(columNumber)

        # USE setObjectName() to give your object a new name
        # Create a frame with updated style
        self.clearance_frame = QFrame(self.ui.ProductClearanceScrollArea)
        self.clearance_frame.setObjectName(newName)
        self.clearance_frame.setMinimumSize(QSize(260, 240))
        self.clearance_frame.setStyleSheet(u"background-color: rgb(3, 61, 100); border: 1px solid #ccc; border-radius: 5px; font-size: 12px;")
        self.clearance_frame.setFrameShape(QFrame.StyledPanel)
        self.clearance_frame.setFrameShadow(QFrame.Raised)
        setattr(self.ui, newName,  self.clearance_frame)

        # Create a vertical layout for the frame
        frame_layout = QVBoxLayout(self.clearance_frame)
        frame_layout.setAlignment(Qt.AlignHCenter | Qt.AlignCenter)  # Set alignment to top

        # Create labels to display product information
        product_name_label = QLabel()
        product_name_label.setText("Name: {}".format(product_detail['name']))
        product_name_label.setStyleSheet("font-weight: bold;")
        product_brand_label = QLabel()
        product_brand_label.setText("Brand: {}".format(product_detail['brand']))
        product_price_label = QLabel()
        product_price_label.setText("Orginal Price: {}".format(product_detail['Price']))
        product_discount_price_label = QLabel()
        product_discount_price_label.setText("Discount Price: {}".format(product_detail['discount']))
        product_discount_price_label.setStyleSheet("font-weight: bold; font-size: 16px; color: red;")

        # Add the button layout to the frame layout
        frame_layout.addWidget(product_name_label)
        frame_layout.addWidget(product_brand_label)
        frame_layout.addWidget(product_price_label)
        frame_layout.addWidget(product_discount_price_label)

        # Set the layout of the frame to the created frame layout
        self.clearance_frame.setLayout(frame_layout)

        self.ui.ProductClearanceGridLayout.addWidget( self.clearance_frame, rowNumber, columNumber, 1, 1,
                                                     Qt.AlignHCenter | Qt.AlignVCenter)
    def clear_product(self):
        while self.ui.ProductClearanceGridLayout.count() > 0:
            item = self.ui.ProductClearanceGridLayout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.setParent(None)
                widget.deleteLater()

        self.ui.ProductClearanceGridLayout.update()


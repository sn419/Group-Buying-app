class NotesUserInterface:
    def __init__(self,ui):
        self.ui = ui
    def load_note_ui(self, notes):
        for note in notes:
            self.ui.NoteListArea.addItem(note[1])

    def add_note_ui(self):
        # UI logic to add a note from UI
        note = self.ui.NoteTextLine.text()
        self.ui.NoteListArea.addItem(note)
        self.ui.NoteTextLine.setText("")
        return note

    def delete_note_ui(self,ui):
        # UI logic to delete a note from UI
        select_item  = self.ui.NoteListArea.selectedItems()
        if len(select_item) > 0:
            for item in select_item:
                self.ui.NoteListArea.takeItem(self.ui.NoteListArea.row(item))
                return item.text()


    def clear_field(self):
        self.ui.NoteListArea.clear()







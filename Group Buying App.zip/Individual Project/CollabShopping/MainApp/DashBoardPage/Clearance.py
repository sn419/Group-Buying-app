from MainApp.DashBoardPage.ClearanceUi import ProductClearanceUi
class ProductClearance:

    def __init__(self, ui, dataset):
        self.ui = ui
        self.dataset = dataset
        self.Product_clearance_View = ProductClearanceUi(ui)



    def apply_product_clearance(self):
        filtered_products = self.get_product_deals()
        self.Product_clearance_View.set_product(filtered_products)
        self.Product_clearance_View.product_info(len(filtered_products))

    def get_product_deals(self):
        """
        Get products where the discounted price is lower than the original price.
        :return: List of products with discounted price lower than price.
        """
        discounted_price_lower_than_price = {}
        for (seller_id, product_id), product in self.dataset.items():
            if product['discount'] < product['Price']:
                key = (seller_id, product_id)
                discounted_price_lower_than_price[key] = product
        return discounted_price_lower_than_price

    def clear_clearance(self):
        self.Product_clearance_View.clear_product()

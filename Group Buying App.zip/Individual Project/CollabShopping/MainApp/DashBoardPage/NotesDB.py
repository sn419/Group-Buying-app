import datetime
class NotesRecord:
    def __init__(self,db):
        self.db = db
    def load_note_db(self,username):
        try :
            query = "SELECT * FROM UserNotes WHERE  Username = %s "
            values = (username,)
            self.db.execute(query, values)
            result = self.db.fetch_all()
            return result
        except Exception as e:
            print("Error loading record:", e)



    def add_note_db(self,username, note):
        date = str(datetime.datetime.today().date())
        try:
            sql_stmt = "INSERT INTO UserNotes(Username,Note,Date)VALUES (%s, %s, %s)"
            values = (username, note, date)
            self.db.execute(sql_stmt, values)
            self.db.db_commit()
        except Exception as e:
            print("Error adding record:", e)


    def delete_note_db(self,username,note):
        try:
            sql_stmt = "DELETE FROM UserNotes WHERE Username = %s AND Note =%s"
            values = (username,note)
            self.db.execute(sql_stmt, values)
            self.db.db_commit()
        except Exception as e:
             print("Error deleting record:", e)


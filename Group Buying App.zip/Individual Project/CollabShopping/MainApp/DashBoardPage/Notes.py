from MainApp.DashBoardPage.NotesDB import NotesRecord
from MainApp.DashBoardPage.NoteUi import NotesUserInterface

class Notes:
    def __init__(self,MainUi,database):
        self.MainUi = MainUi
        self.database = database
        self.NotesUi = NotesUserInterface(MainUi)
        self.Notedb = NotesRecord(database)

    def load_notes(self, username):
        # Call UI and DB methods to load notes
        notes_db = self.Notedb.load_note_db(username)
        if notes_db is not None:
            print("df", username, notes_db)
            self.NotesUi.load_note_ui(notes_db)
        else:
             print("No notes found for username:", username)

    def add_note(self, username):
        # Call UI and DB methods to add a note
        note = self.MainUi.NoteTextLine.text()
        if len(note) != 0:
            self.MainUi.NotesAdd_Btn.clicked.connect(self.NotesUi.add_note_ui)
            self.Notedb.add_note_db(username,note)
        else:
            print("enter your note")

    def delete_note(self, username):
        # Call UI and DB methods to delete a note
        note = self.NotesUi.delete_note_ui(self.MainUi)
        print(note,"delete a note")
        self.Notedb.delete_note_db(username, note)

    def clear_note_field(self):
        self.NotesUi.clear_field()
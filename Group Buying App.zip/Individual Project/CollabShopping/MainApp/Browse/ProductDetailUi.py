class IndividualProductDetails:
    def __init__(self, ui,stitch_system):
        self.stitch_system = stitch_system
        self.ui = ui
        self.seller_id = None
        self.product_id = None
        self.product_info = None

        self.ui.ProductViewBack_Btn.clicked.connect(lambda: self.previous_page())


    def set_product_detail(self, seller_id, product_id, product_info):
        self.seller_id = seller_id
        self.product_id = product_id
        self.product_info = product_info

        # set stitch detail
        self.stitch_system.set_reserve_product(seller_id,product_id)

    def set_product_page_detail(self):
        self.ui.ProductNameLabel.setText(self.product_info["name"])
        self.ui.ProductOriginalPriceLabel.setText("£" + str(self.product_info["Price"]))
        self.ui.ProductDiscountPriceLabel.setText("£" + str(self.product_info["discount"]))
        self.ui.ProductDetailDescriptionLabel.setText(self.product_info["description"])
        self.ui.ProductDetailBrandLabel.setText("Brand: " + self.product_info["brand"])
        self.ui.ProductDetailCategoryLabel.setText("Category: " + self.product_info["category"])

    def clear_product_page_detail(self):
        self.ui.ProductNameLabel.setText('')
        self.ui.ProductOriginalPriceLabel.setText('')
        self.ui.ProductDiscountPriceLabel.setText('')
        self.ui.ProductDetailDescriptionLabel.setText('')
        self.ui.ProductDetailBrandLabel.setText('')
        self.ui.ProductDetailCategoryLabel.setText('')

    def previous_page(self):
        self.clear_product_page_detail()
        self.ui.BrowsePageStackedWidget.setCurrentWidget(self.ui.BrowsePageProductView)

    def get_seller_product_ids(self):
        return (self.seller_id,self.product_id)

from MainApp.MultipleSellers import Sellers

class AllProductsInfo:
    def __init__(self):
        self.sellers = Sellers()
        self.AllProducts = {}

        """Retrieve all the products from different sellers and add to all product hashmap"""
        self.set_all_products()

    def set_all_products(self):
        """Retrieve the information of the sellers"""
        sellers_info = self.sellers.get_all_sellers()

        """for each seller retrieve all the  products """
        for item, key in sellers_info.items():
            seller_id = item
            seller_api = key

            seller_products = seller_api.products_info()
            seller_products_details = seller_products['products']
            for each_product in seller_products_details:
                product_infomation = each_product
                self.AllProducts[(seller_id, product_infomation['product_id'])] = product_infomation

    def get_all_product(self):
        return self.AllProducts


class CompanyCommission:
    def __init__(self):
        self.commission = 0.08

    def get_commision(self):
        return self.commission

    def set_commision(self, rate):
        self.commission = rate


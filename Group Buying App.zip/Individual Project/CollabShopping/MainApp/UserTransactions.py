
class UserTransactionsRecords:

    def save_transaction_record(self, db, user_id, order_id, amount):
        try:
            sql_stmt = "INSERT INTO UserTransactionRecords(UserId,TransactionId,Amount) VALUES (%s, %s,%s)"
            values = (user_id, order_id, amount)
            db.execute(sql_stmt, values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)

    def delete_transaction_record(self, db, user_id, order_id):
        try:
            sql_stmt = "DELETE FROM UserTransactionRecords WHERE UserId = %s AND TransactionId = %s"
            values = (user_id, order_id)
            db.execute(sql_stmt, values)
            db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)


    def get_transaction_record(self,db,user_id,order_id):
        try:
             query ="SELECT SellerId,ProductId,Quantity,TotalAmount FROM CompanyTransactionRecords ctr JOIN UserTransactionRecords utr ON ctr.TransactionId = utr.TransactionId WHERE ctr.TransactionId =%s"
             values = (order_id,)
             db.execute(query, values)
             result = db.fetch_all()
             print(result)
        except Exception as e:
             print("Error deleting record:", e)



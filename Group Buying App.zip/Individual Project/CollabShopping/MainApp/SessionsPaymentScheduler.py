from MainApp.Cart import ShoppingBasket
from MainApp.MultipleSellers import Sellers
from MainApp.GroupTotalDivider import GroupBillDivider

class PaymentScheduler:
    def __init__(self):
        self.bill_divider = GroupBillDivider()
        self.sellers = Sellers()

    def set_schedule_payment(self, sessions):

        for key, value in sessions.items():
            SellerId = key[0]
            ProductId = key[1]

            total_quantity = 0
            for user_product in value:
                total_quantity += user_product[1]

            basket = ShoppingBasket(self.sellers, SellerId, ProductId,total_quantity)
            self.bill_divider.get_seller_product_cost(basket, key, value,total_quantity)
            return


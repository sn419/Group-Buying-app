import requests


class Seller:
    def __init__(self, name, sellerid, api):
        self.name = name
        self.api = api
        self.seller_id = sellerid
    """Get products information"""
    def products_info(self):
        endpoint = '/search'
        url = self.api + endpoint
        response = requests.get(url)
        return response.json()
    """Check sellers Inventory"""
    def check_product_quantity(self, product_id, quantity):
        endpoint = '/product_quantity'
        url = self.api + endpoint
        response = requests.get(url, params={'ProductId': product_id})
        response = response.json()
        if int(response['ProductQuantity']) < quantity:
            return False
        return True
    def set_seller_id(self):
        endpoint = '/seller_id'
        url = self.api + endpoint
        response = requests.get(url)
        response = response.json()
        self.seller_id = int(response['SellerId'])

    def get_seller_id(self):
        return self.seller_id

    def get_product_price(self, product_id):
        endpoint = '/product_price'
        url = self.api + endpoint
        response = requests.get(url, params={'ProductId': int(product_id)})
        response = response.json()
        return response['ProductPrice']

    def deduct_product_quantity(self, product_id, quantity):
        endpoint = '/reduce_product_quantity'
        url = self.api + endpoint
        response = requests.post(url, params={'ProductId': product_id, 'ProductQuantity': quantity})
        response = response.json()
        print(response)

    def get_shopping_cart_cost(self, product_id, quantity):
        endpoint = '/shopping_cart'
        url = self.api + endpoint
        response = requests.get(url, params={'ProductId': product_id, "ProductQuantity": quantity})
        response = response.json()
        if 'ProductCost' in response:
            return response['ProductCost']
        else:
            print(response)

    def update_product_rating(self,product_id, rating):
        endpoint = '/update_rating'
        url = self.api + endpoint
        response = requests.post(url, params={'ProductId': product_id, 'Rating':rating})
        if response.status_code == 200:
            print(response.json())
        else:
            print("Failed to update rating")


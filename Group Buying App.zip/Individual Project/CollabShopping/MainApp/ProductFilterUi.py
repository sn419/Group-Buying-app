from MainApp.ProductsFilterClass import ProductsFilter
from MainApp.MainAppUi.CatalogueUi import ProductsView


class ProductFilterUserInterface:

    def __init__(self, ui, dataset,individual_product_view):
        self.individual_product_view = individual_product_view
        self.dataset = dataset
        self.ui = ui
        self.product_filter = ProductsFilter()
        self.product_view = ProductsView(ui, individual_product_view)
        self.apply()



    def apply(self):
        self.ui.ProducSearch_Btn.clicked.connect(lambda: self.implement_product_ui(self.Apply_Product_filter()))
        self.ui.Deals_Btn.clicked.connect(lambda: self.implement_product_ui(self.apply_best_deal_products_filter()))
        self.ui.BestSeller_Btn.clicked.connect(
            lambda: self.implement_product_ui(self.apply_best_seller_product_filter()))
        self.ui.CategoryComboBox.currentIndexChanged.connect(
            lambda: self.implement_product_ui(self.apply_category_filter()))

    def implement_product_ui(self, filtered_product):
        self.product_filter.set_dataset(self.dataset)
        filtered_products = filtered_product
        self.product_view.clear_product()
        self.product_view.set_product(filtered_products)
        self.product_view.product_info(len(filtered_products))

    def Apply_Product_filter(self):
        self.product_filter.set_dataset(self.dataset)

        """Set the type of filter do you want to show the products """
        selected_filter_option = self.ui.ProductDropDownBox.currentText()

        # Get the text entered in the search bar
        search_text = self.ui.ProductSearchBar.text()

        if len(search_text) > 0:
            filtered_products = self.product_filter.filter_by_search_box(search_text)
            self.product_filter.set_dataset(filtered_products)
            if selected_filter_option != "Choose":

                if selected_filter_option == "Low-high":
                    sorted_products = self.product_filter.filter_by_price('low-high')
                    # Return filtered and sorted products
                    return sorted_products
                elif selected_filter_option == "High-Low":
                    sorted_products = self.product_filter.filter_by_price('high-low')
                    # Return filtered and sorted products
                    return sorted_products
                elif selected_filter_option == "Rating":
                    filtered_by_rating = self.product_filter.filter_by_rating()
                    return filtered_by_rating
            else:
                return filtered_products

    def apply_best_deal_products_filter(self):
        self.product_filter.set_dataset(self.dataset)

        return self.product_filter.get_product_deals()

    def apply_best_seller_product_filter(self):
        self.product_filter.set_dataset(self.dataset)

        return self.product_filter.get_best_seller_products()

    def apply_category_filter(self):
        self.product_filter.set_dataset(self.dataset)

        selected_filter_option = self.ui.CategoryComboBox.currentText()

        return self.product_filter.filter_by_category(selected_filter_option)



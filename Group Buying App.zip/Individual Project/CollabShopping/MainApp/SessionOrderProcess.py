from MainApp.SessionsPaymentScheduler import PaymentScheduler
from MainApp.SessionsChecker import  SessionsManager
from MainApp.AccessUserBank import  UserCard
from MainApp.UserTransactions import UserTransactionsRecords
class SessionsProcess:
    def __init__(self,db):
        self.db = db
        self.scheduler = PaymentScheduler()
        self.session_end = SessionsManager(db)
        self.user_payment = UserCard(db)
        self.user_transaction = UserTransactionsRecords()


    def process_session(self):
        sessions = self.session_end.get_expired_sessions()
        if len(sessions) > 0:
            payment_scheduler = self.scheduler.set_schedule_payment(sessions)
            for key, participants in sessions:
                session_participants = participants
                for user in session_participants:
                    self.user_payment.user_pay(user[0],user[1])
                    self.session_end.delete_expired_sessions(key)
                    self.user_transaction.save_transaction_record(self.db,user[0],key,user[1])
        else:
            print("you do not have any session to process")


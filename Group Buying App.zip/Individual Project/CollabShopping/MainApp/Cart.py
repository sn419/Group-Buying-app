class ShoppingBasket:
    def __init__(self, sellers, seller_id, product_id, total_quantity):
        self.seller_id = seller_id
        self.product_id = product_id
        self.total_quantity = total_quantity
        self.sellers = sellers
        self.current_seller = self.sellers.get_seller(self.seller_id)
        self.unit_price = 0
        self.total = 0

    def get_sub_total(self):
        sub_total_cost = self.current_seller.get_product_price(self.product_id)
        return sub_total_cost * self.total_quantity

    def set_total(self):
        self.total = self.current_seller.get_shopping_cart_cost(self.product_id, self.total_quantity)
        print(self.total)

    def update_total(self, amount):
        self.total = amount
        self.unit_price = amount / self.total_quantity

    def get_total(self):
        return self.total

    def get_unit_price(self):
        return self.unit_price


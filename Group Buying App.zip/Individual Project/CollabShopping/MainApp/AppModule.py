import sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMainWindow
import keyring

# general import files
from MainApp.MainAppUi.menuBar import Ui_MainWindow
from MainApp.MainAppUi.Module_Ui_Functions import *
from User import *
from MainApp.MainSQL.UserinformationDB import UserDB
from db_connection import DB

# Dashboard imports
from MainApp.DashBoardPage.Notes import Notes
from MainApp.DashBoardPage.Clearance import ProductClearance

# AccountPage imports
from MainApp.AccountPage.CardDetailFunctions import *
from MainApp.AccountPage.EditProfile import EditProfileUi

# BrowsePage Imports
from MainApp.SellersProductsInfo import AllProductsInfo
from MainApp.ProductFilterUi import ProductFilterUserInterface
from MainApp.Browse.ProductDetailUi import IndividualProductDetails
from MainApp.ProductOrderCombine import StitchOrderSystem
from MainApp.SessionOrderProcess import SessionsProcess

class ModuleMainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        ModuleMainWindow.setWindowTitle(self, "Unify")

        """ Toggle SideMenu """
        self.ui.Menu_Btn.clicked.connect(lambda: UIFunction().side_menu_toggle(self.ui, 250, True))

        """ Main DB class """
        self.MainDB = DB()
        """ userInformation DB statement """
        self.user_db = UserDB(self.MainDB)
        """ Inilitize sessioon """
        self.user_session = UserSession()

        ## Main Menu Pages
        ##############################################
        self.ui.SideMenuStackedWidget.setCurrentWidget(self.ui.DashPage)
        self.ui.DashBoard_Btn.clicked.connect(lambda: self.ui.SideMenuStackedWidget.setCurrentWidget(self.ui.DashPage))
        self.ui.Browse_Btn.clicked.connect(lambda: self.ui.SideMenuStackedWidget.setCurrentWidget(self.ui.BrowsePage))
        self.ui.Orders_Btn.clicked.connect(lambda: self.ui.SideMenuStackedWidget.setCurrentWidget(self.ui.OrdersPage))

        """ Account page """
        # Account page: previous page navigation
        self.ui.EditProfile_back_Btn.clicked.connect(
            lambda: self.ui.ProfilePageStackWidget.setCurrentWidget(self.ui.AccountDisplay))
        self.ui.CardWalletprev_Btn.clicked.connect(
            lambda: self.ui.ProfilePageStackWidget.setCurrentWidget(self.ui.AccountDisplay))

        self.ui.Update_Btn.clicked.connect(
            lambda: self.ui.ProfilePageStackWidget.setCurrentWidget(self.ui.MainProfilePageFrame))
        self.ui.Account_Btn.clicked.connect(self.account)

        """Account Page : edit profile page """
        self.edit_profile_class = EditProfileUi(self.ui, self.user_db, self.user_session)
        self.ui.Update_Btn.clicked.connect(self.fill_edit_profile_fields)
        self.ui.Update_Btn_2.clicked.connect(self.update_edit_profile_fields)

        # Account Page : Card wallet
        self.ui.Payment_Btn.clicked.connect(
            lambda: self.ui.ProfilePageStackWidget.setCurrentWidget(self.ui.MainPaymentFrame))
        self.ui.AddCard_Btn.clicked.connect(lambda: self.ui.WalletStackedWidget.setCurrentWidget(self.ui.BankCard))
        self.ui.AddBankCard_Btn.clicked.connect(
            lambda: self.ui.WalletStackedWidget.setCurrentWidget(self.ui.CardsWallet))

        """Browse Page"""
        from MainApp.AccountPage.Wallet import CardsWallet
        self.user_bank_cards = CardsWallet(self.MainDB, self.ui)
        self.ui.AddBankCard_Btn.clicked.connect(
            lambda: self.user_bank_cards.add_card(self.user_session.get_user_email()))
        self.ui.RemoveCard_Btn.clicked.connect(
            lambda: self.user_bank_cards.delete_user_card(self.user_session.get_user_email()))



        """Stitch order system """

        stitch_order_system = StitchOrderSystem(self.MainDB,self.ui)
        "different sellers product into one file"
        self.all_product_class = AllProductsInfo()
        self.products = self.all_product_class.get_all_product()


        """Individual product details class """
        individual_product_info_class = IndividualProductDetails(self.ui,stitch_order_system)
        """ shows all the products based on the product filtered  applied by the user """
        all_products_display_ui = ProductFilterUserInterface(self.ui, self.products, individual_product_info_class)

        """ DASHBOARD """
        self.NoteFeature = Notes(self.ui, self.MainDB)
        self.ui.NotesAdd_Btn.clicked.connect(lambda: self.NoteFeature.add_note(self.user_session.get_user_email()))
        self.ui.NotesRemove_Btn.clicked.connect(
            lambda: self.NoteFeature.delete_note(self.user_session.get_user_email()))

        self.clearance_product_class = ProductClearance(self.ui, self.products)

        "session process "
        proces_session_class = SessionsProcess(self.MainDB)
        proces_session_class.process_session()


        self.show()

    def create_session(self, email, password):
        self.user_session.create_session(email, password)
        user_email = self.user_session.get_user_email()

        self.NoteFeature.load_notes(user_email)
        self.user_bank_cards.load_user_cards(user_email)

        self.clearance_product_class.apply_product_clearance()

        print("a session started for:{}".format(user_email))

    def destroy_session(self):
        name = self.user_session.get_user_email()
        self.user_session.destroy_session(self.user_session.get_user_email())
        self.NoteFeature.clear_note_field()
        self.user_bank_cards.clear_user_wallet()
        self.clearance_product_class.clear_clearance()
        print("session destroyed:{}".format(name))

    def account(self):
        email = self.user_session.get_user_email()
        name = self.user_db.get_name(email)
        self.ui.SideMenuStackedWidget.setCurrentWidget(self.ui.AccountPage)
        self.ui.AccountPageUserEmail.setText(email)
        self.ui.AccountPageUserName.setText(name)

    def fill_edit_profile_fields(self):
        self.edit_profile_class.fill_edit_profile_fields()
        self.ui.ProfilePageStackWidget.setCurrentWidget(self.ui.MainProfilePageFrame)

    def update_edit_profile_fields(self):
        self.edit_profile_class.update_edit_profile_fields()
        self.ui.ProfilePageStackWidget.setCurrentWidget(self.ui.AccountDisplay)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ui = ModuleMainWindow()
    sys.exit(app.exec_())

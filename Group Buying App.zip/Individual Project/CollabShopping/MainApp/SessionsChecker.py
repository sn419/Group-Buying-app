import datetime


class SessionsManager:
    def __init__(self, db):
        self.db = db

    def get_expired_sessions(self):

        current = datetime.datetime.now()
        expired = int(current.timestamp() / 60)
        try:
            sql_stmt = "SELECT SellerID,ProductId From ActiveSessions WHERE SessionExpire < %s "
            values = (expired,)
            self.db.execute(sql_stmt, values)
            result = self.db.fetch_all()
            return result
        except Exception as e:
            print("Error deleting record:", e)

    def delete_expired_sessions(self, expired_sessions):
        # delete all the session that are expired

        for session in expired_sessions:
            try:
                sql_stmt = "DELETE FROM ActiveSessions WHERE SellerID = %s AND ProductId = %s"
                values = (session[0], session[1])
                self.db.execute(sql_stmt, values)
                self.db.db_commit()
            except Exception as e:
                print("Error deleting record:", e)

    def get_user_expired_session(self, expired_sessions):

        """
          input  : [[sellerid,productid],...]
          output : (sellerid,productid) :[(userid,quantity),(userid,quantity)]

        """
        sellers_product_sales = {}
        for session in expired_sessions:
            try:
                sql_stmt = "DELETE FROM ActiveSessions WHERE SellerID = %s AND ProductId = %s"
                values = (session[0], session[1])
                self.db.execute(sql_stmt, values)
                result = self.db.fetch_all()
                sellers_product_sales[(session[0], session[1])] = result
            except Exception as e:
                print(e)
        return sellers_product_sales

    def delete_user_expird_session(self, sellers_product_sales):
        """"

        input (sellerid,productid) :[(userid,quantity),(userid,quantity)]

        """
        for key, value, in sellers_product_sales.items():
            seller_id = key[0]
            product_id = key[1]
            try:
                sql_stmt = "DELETE FROM UserActiveSession WHERE SellerID = %s AND ProductId = %s"
                values = (seller_id, product_id)
                self.db.execute(sql_stmt, values)
                self.db.db_commit()
            except Exception as e:
                print(e)


#l = {(43454, 4545): [('sn@gmail.com', 200), ('bf@gmail.com', 100)],
#     (4321, 3424): [('d@dsj.com', 100), ('jh@gmail.com', 140)]}

#la = SessionsManager(DB())

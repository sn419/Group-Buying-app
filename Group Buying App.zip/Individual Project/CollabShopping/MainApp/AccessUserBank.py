
class UserCard:
    def __init__(self,db):
        self.db = db


    def user_pay(self,userid,quantity):

        try:
            sql_stmt = " UPDATE UserBankCardsDetail SET Balance =Quantity - %s WHERE UserId = %s "
            values = (quantity,userid)
            self.db.execute(sql_stmt,values)
            self.db.db_commit()
        except Exception as e:
            print("Error deleting record:", e)



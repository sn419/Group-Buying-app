from MainApp.Commission import CompanyCommission
from MainApp.UserTransactions import UserTransactionsRecords
from MainApp.CompanyTransaction import CompanyTransactionsRecords
from MainApp.CommissionRecords import CompanyCommissionRecords
from db_connection import DB


class GroupBillDivider:
    def __init__(self):
        self.CompanyCommission = CompanyCommission()
        self.UserTransactionRecord = UserTransactionsRecords()
        self.CompanyTransactionRecords = CompanyTransactionsRecords()
        self.CompanyCommissionRecords = CompanyCommissionRecords()
        self.database = DB()

    def get_seller_product_cost(self, cart, sellerInfo, session,quantity):
        # get product cost from seller
        cart.set_total()
        total_product_cost = cart.get_total()

        # calculate commission and cart update
        commission_amount = self.CompanyCommission.get_commision() * total_product_cost
        total_product_cost -= commission_amount
        cart.update_total(total_product_cost)

        # save the commission amount into Company records
        transaction_id = self.CompanyTransactionRecords.get_transaction_id()
        self.CompanyCommissionRecords.save_commision_record(self.database, transaction_id, total_product_cost)
        self.CompanyTransactionRecords.save_transaction_record(self.database,transaction_id,sellerInfo[0],sellerInfo[1],quantity,total_product_cost)
        # calculate cost of product for each user per quantity
        unit_product_cost = cart.get_unit_price()
        seller_product_sales = session
        for i in range(len(seller_product_sales)):
            seller_product_sales[i][1] = seller_product_sales[i][1] * unit_product_cost
            self.UserTransactionRecord.save_transaction_record(self.database, seller_product_sales[i][0],
                                                               transaction_id, seller_product_sales[i][1])


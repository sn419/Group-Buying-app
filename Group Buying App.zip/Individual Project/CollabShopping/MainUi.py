from PyQt5.QtWidgets import QApplication, QMainWindow, QStackedWidget
from PyQt6.QtWidgets import QStackedLayout

from Authentication.LoginPage import *
from MainApp.AppModule import ModuleMainWindow
from Authentication.LoginFunction import LoginPageFunctions

class UiMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Create a stacked widget as the central widget
        self.central_widget = QStackedWidget()
        self.setCentralWidget(self.central_widget)
        self.setWindowTitle("Unify")
        self.setWindowIcon(QtGui.QIcon("MainApp/MainAppUi/white_feather/company_logo.png"))


        # Pages of the central stackwidget
        self.page1 = Login_Page()
        self.page2 = ModuleMainWindow()
        self.page2.hide()
        self.central_widget.addWidget(self.page1)


        ###### LoginPage
        self.login_page_statement = LoginPageFunctions(self.page1)
        self.page1.LoginButton.clicked.connect(self.login_page_checks)

        ## logout page
        if self.page2:
            self.page2.ui.Logout_Btn.clicked.connect(self.Logout)

        self.show()


    def login_page_checks(self):
            username =self.page1.UserNameField.text()
            password =self.page1.PasswordField.text()

            if self.login_page_statement.check_field() == True:
                if self.login_page_statement.check_sign_in_details():

                    ## Create a session for the user
                    self.page2.create_session(username,password)
                    # navigate to the app page
                    self.page2.show()
                    self.central_widget.addWidget(self.page2)
                    self.central_widget.setCurrentWidget(self.page2)
                else:
                    print("the details doesn't exist")
            else:
                print(" Sign in page form incomplete")


    def Logout(self):
        self.page2.destroy_session()
        self.central_widget.removeWidget(self.page2)
        self.central_widget.setCurrentWidget(self.page1)
        self.resize(750,600)



if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = UiMainWindow()
    window.show()
    app.exec_()
